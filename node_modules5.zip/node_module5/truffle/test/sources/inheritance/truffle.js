module.exports = {
  compilers: {
    solc: {
      version: "0.5.0"
    }
  }
};
