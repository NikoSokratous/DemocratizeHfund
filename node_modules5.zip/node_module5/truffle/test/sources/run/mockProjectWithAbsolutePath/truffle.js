module.exports = {
  plugins: ["truffle-mock"]
};
