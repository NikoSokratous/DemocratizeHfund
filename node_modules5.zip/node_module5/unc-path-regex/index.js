'use strict';

module.exports = function uncPathRegex() {
  return /^[\\\/]{2,}[^\\\/]+[\\\/]+[^\\\/]+/;
};
