declare function upperCase (value: string, locale?: string): string;

export = upperCase;
