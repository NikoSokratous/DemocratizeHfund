# ts-invariant

[TypeScript](https://www.typescriptlang.org) implementation of
[`invariant(condition, message)`](https://www.npmjs.com/package/invariant).
