var punycode = {};
try { punycode = require("punycode"); } catch (e) { }
module.exports = punycode;