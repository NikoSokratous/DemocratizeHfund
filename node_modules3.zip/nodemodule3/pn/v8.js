var v8 = {};
try { v8 = require("v8"); } catch (e) { }
module.exports = v8;