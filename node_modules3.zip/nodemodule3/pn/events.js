var events = require("events");
module.exports = events;